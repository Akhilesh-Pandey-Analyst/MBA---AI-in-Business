# Simple sample code for grabbing json data from web and storing in csv
import requests
import csv

# Step 1: Fetch JSON data from a public API
url = "https://jsonplaceholder.typicode.com/users"  # Sample user data
response = requests.get(url)
response.raise_for_status()
data = response.json()

# print data
print("JSON data read is :")
print(data)
print()


# Step 2: Parse and flatten the data
rows = []
for user in data:
    row = {
        "id": user["id"],
        "name": user["name"],
        "username": user["username"],
        "email": user["email"],
        "city": user["address"]["city"],
        "company": user["company"]["name"]
    }
    rows.append(row)

# Step 3: Write to CSV
with open("users.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

print("Data saved to users.csv")
