# Simple sample code for grabbing csv data from web and storing in csv
import requests
import csv
import io

# Step 1: URL of the CSV file
url = "https://people.sc.fsu.edu/~jburkardt/data/csv/hw_200.csv"  # Sample height/weight data

# Step 2: Download the CSV content
response = requests.get(url)
response.raise_for_status()  # Raise error if download fails

# print the raw data read
print(response.text)  # This prints the entire CSV content as a string
print()

# Step 3: Parse CSV content
csv_data = csv.reader(io.StringIO(response.text))
header = next(csv_data)  # Skip header row


# Step 4: Filter or transform
# Filter out empty rows
rows = []
for row in csv_data:
    if row:  # Skip empty rows
        rows.append(row)

# Filter rows where height > 70
filtered_rows = [header]
for row in rows:
    try:
        height = float(row[1])  # Height is in the second column
        if height > 70:
            filtered_rows.append(row)
    except (ValueError, IndexError):
        continue  # Skip rows with missing or invalid data
    


# Step 5: Save to a new CSV file
with open("filtered_data.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerows(filtered_rows)

print("Data saved to filtered_data.csv")
