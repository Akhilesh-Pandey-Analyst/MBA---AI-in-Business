# Program 6A - WEATHER LOGGER
# OpenWeatherMap API to fetch current weather data for a given city

'''
1. Go to https://openweathermap.org/api
2. Sign up and generate a free API key
3. Replace "your_api_key_here" in the code with your actual key

'''

import requests
import csv
import time
from datetime import datetime
import matplotlib.pyplot as plt
import pandas as pd

# Step 1: API setup
API_KEY = "a168b82e2b29cf5a1feabc30ec5e7883"  # Replace with your OpenWeatherMap API key
CITY = "Mumbai"
# The API end point is here
URL = f"https://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"
CSV_FILE = "weather_log.csv"

# Step 2: Initialize CSV file
with open(CSV_FILE, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(["Timestamp", "Temperature (°C)", "Humidity (%)"])

# Step 3: Collect data over time
for _ in range(6):  # Collect data every minute for 6 minutes
    try:
        # GET request to collect data from the endpoint
        response = requests.get(URL)
        data = response.json()

        if response.status_code == 200 and "main" in data:
            temp = data["main"]["temp"]
            humidity = data["main"]["humidity"]
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            print(f"[{timestamp}] Temp: {temp}°C, Humidity: {humidity}%")

            with open(CSV_FILE, mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([timestamp, temp, humidity])
        else:
            print("API Error:", data.get("message", "Unknown error"))

        time.sleep(60)
    except Exception as e:
        print("Error:", e)
        time.sleep(60)

        
# Step 4: Visualize the data
df = pd.read_csv(CSV_FILE)
df["Timestamp"] = pd.to_datetime(df["Timestamp"])

plt.figure(figsize=(10, 6))
plt.plot(df["Timestamp"], df["Temperature (°C)"], label="Temperature (°C)", marker='o')
plt.plot(df["Timestamp"], df["Humidity (%)"], label="Humidity (%)", marker='x')
plt.title(f"Weather Trends in {CITY}")
plt.xlabel("Time")
plt.ylabel("Value")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
