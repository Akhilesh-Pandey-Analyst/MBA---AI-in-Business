# Simple sample code for grabbing xml data from web and storing in csv
import requests
import xml.etree.ElementTree as ET
import csv

# Step 1: Fetch XML data
url = "https://www.w3schools.com/xml/simple.xml"
response = requests.get(url)
root = ET.fromstring(response.content)
print(response.text)  # This prints the full XML content



# Step 2: Extract data
menu_items = []
for food in root.findall("food"):
    item = {
        "name": food.findtext("name"),
        "price": food.findtext("price"),
        "description": food.findtext("description"),
        "calories": food.findtext("calories")
    }
    menu_items.append(item)

# Step 3: Write to CSV
with open("menu.csv", mode="w+", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=menu_items[0].keys())
    writer.writeheader()
    writer.writerows(menu_items)

print("Menu data saved to menu.csv")
