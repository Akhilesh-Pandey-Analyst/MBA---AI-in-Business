# Program 2
# Demonstrates use of API calls to access data from external Web Services

'''
This example retrieves the latest business news news from the news API.
We need the API key.

'''

# pip install requests

import requests
import json

def fetch_and_print_articles(api_url):
    response = requests.get(api_url)
    print('Response Code is: ',response.status_code)
    print()
    if response.status_code == 200:
        articles = response.json().get('articles', [])
        
        for index, article in enumerate(articles[:1], start=1):
            print(f"Article {index}:\n{json.dumps(article, sort_keys=True, indent=4)}\n")
    else:
        print(f"Error: {response.status_code}")

API_KEY = '89d7ff2eb06746aa9f5049ab8a73cfb6'

# try these end points
api_endpoint = f"https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey={API_KEY}"

#api_endpoint= f"https://newsapi.org/v2/everything?q=tesla&from=2025-10-18&sortBy=publishedAt&apiKey={API_KEY}"

#api_endpoint = f"https://newsapi.org/v2/top-headlines?country=us&category=sports&apiKey={API_KEY}"

#api_endpoint = f"https://newsapi.org/v2/everything?q=apple&from=2025-11-17&to=2025-11-17&sortBy=popularity&apiKey={API_KEY}"


fetch_and_print_articles(api_endpoint)

def jprint(obj):
    print(json.dumps(obj, sort_keys=True, indent=4))
