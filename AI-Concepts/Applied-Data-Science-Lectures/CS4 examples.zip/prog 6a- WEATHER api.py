# Program 6A - WEATHER API
# OpenWeatherMap API to fetch current weather data for a given city

'''
1. Go to https://openweathermap.org/api
2. Sign up and generate a free API key
3. Replace "your_api_key_here" in the code with your actual key

'''

import requests

# Step 1: Define the API endpoint and your API key
API_KEY = "a168b82e2b29cf5a1feabc30ec5e7883"  # Replace with your actual API key
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

# Step 2: Set up parameters
city = "Mumbai"
params = {
    "q": city,
    "appid": API_KEY,
    "units": "metric"  # Use "imperial" for Fahrenheit
}

# Step 3: Make the GET request
response = requests.get(BASE_URL, params=params)

# Step 4: Check response status and parse JSON
if response.status_code == 200:
    data = response.json()
    weather = {
        "City": data["name"],
        "Temperature (°C)": data["main"]["temp"],
        "Weather": data["weather"][0]["description"],
        "Humidity (%)": data["main"]["humidity"],
        "Wind Speed (m/s)": data["wind"]["speed"]
    }

    # Step 5: Display the data
    print("Current Weather Data:")
    for key, value in weather.items():
        print(f"{key}: {value}")
else:
    print(f"Failed to retrieve data: {response.status_code}")
