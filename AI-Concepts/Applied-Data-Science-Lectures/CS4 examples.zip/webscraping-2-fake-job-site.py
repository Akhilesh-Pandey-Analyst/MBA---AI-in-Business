# Web scraping demo -1
# pip install requests beautifulsoup4

import requests
from bs4 import BeautifulSoup
import csv

# Step 1: Choose a target URL
'''
- Requests the page at https://realpython.github.io/fake-jobs/  ,
a safe demo site for scraping practice
'''

# Step 1: Target URL
url = "https://realpython.github.io/fake-jobs/"

# Step 2: Send HTTP GET request
response = requests.get(url)
if response.status_code != 200:
    raise Exception(f"Failed to load page ({response.status_code})")

# Step 3: Parse HTML content
soup = BeautifulSoup(response.text, 'html.parser')

# Step 4: Find all job listings
job_cards = soup.find_all('div', class_='card-content')

# Step 5: Extract data for title, company name and location
jobs = []
for job in job_cards:
    title = job.find('h2', class_='title').text.strip()
    company = job.find('h3', class_='company').text.strip()
    location = job.find('p', class_='location').text.strip()
    jobs.append({
        'Title': title,
        'Company': company,
        'Location': location
    })

# Step 6: Export to CSV
csv_filename = 'fake_jobs.csv'
with open(csv_filename, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.DictWriter(file, fieldnames=['Title', 'Company', 'Location'])
    writer.writeheader()
    writer.writerows(jobs)

print(f"Scraped {len(jobs)} jobs and saved to '{csv_filename}'")
