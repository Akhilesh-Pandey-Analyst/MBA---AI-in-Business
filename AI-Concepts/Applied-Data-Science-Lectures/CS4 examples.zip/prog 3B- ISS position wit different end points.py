# Program 3B: ISS Crew and Position Tracker (Updated APIs)

"""
Key libraries used:
json: For decoding JSON data from API.
turtle: For graphical map display.
urllib.request: To fetch API data.
time: For periodic updates.
webbrowser: To open files.
geocoder: To find current user location.
requests: For simpler API calls.
"""

import requests, json, turtle, time, webbrowser, geocoder

# Crew API (Open Notify)
crew_url = "http://api.open-notify.org/astros.json"
crew_data = requests.get(crew_url).json()

with open("iss.txt", "w") as file:
    file.write(f"There are currently {crew_data['number']} astronauts in space:\n\n")
    for person in crew_data["people"]:
        file.write(f"{person['name']} - onboard ({person['craft']})\n")

    user_location = geocoder.ip('me')
    file.write(f"\nYour current lat / long is: {user_location.latlng}")

print("Crew info written to iss.txt")

# Position API (WhereTheISS.at)
iss_position_url = "https://api.wheretheiss.at/v1/satellites/25544"

# Turtle setup
screen = turtle.Screen()
screen.setup(width=1280, height=720)
screen.setworldcoordinates(-180, -90, 180, 90)
screen.bgpic("./images/map.gif")
screen.register_shape("./images/iss.gif")

iss = turtle.Turtle()
iss.shape("./images/iss.gif")
iss.penup()

try:
    while True:
        data = requests.get(iss_position_url).json()
        lat, lon = data["latitude"], data["longitude"]
        print(f"Lat: {lat}, Lon: {lon}, Alt: {data['altitude']} km, Vel: {data['velocity']} km/h")
        iss.goto(lon, lat)
        iss.pendown()
        time.sleep(5)
except KeyboardInterrupt:
    print("\nISS tracking stopped by user.")
    turtle.bye()
