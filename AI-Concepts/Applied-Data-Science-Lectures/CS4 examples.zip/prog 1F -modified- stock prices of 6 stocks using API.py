# Stock proces from yfinance

#pip install yfinance


import yfinance as yf
import csv
import time
from datetime import datetime

# List of stock tickers
TICKERS = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "IBM"]
CSV_FILE = "stock_prices.csv"

# Write CSV header
with open(CSV_FILE, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(["Timestamp", "Ticker", "Price"])

# Fetch and store prices
# IMPORTANT: yfinance is a wrapper handling URL construction, requests,
# JSON parsing, rate limiting and retries. 
timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
with open(CSV_FILE, mode='a', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    while True:
        try:
            for ticker in TICKERS:
                try:
                    # yfinance performs an internal RESTful GET request to
                    # yahoo finance endpoint which looks something like this
                    #https://query1.finance.yahoo.com/v7/finance/quote?symbols=AAPL
                    # this end point is not exposed as yfinance is wrapper.
                    stock = yf.Ticker(ticker)
                    price = stock.info.get("regularMarketPrice", "N/A")
                    print(f"[{timestamp}] {ticker}: ${price}")
                    writer.writerow([timestamp, ticker, price])
                    
                except Exception as e:
                    print(f"Error fetching {ticker}: {e}")
                 
            time.sleep(60)
            
        except Exception as e:
            print(f"Error in fetching data : {e}")
            time.sleep(60)
