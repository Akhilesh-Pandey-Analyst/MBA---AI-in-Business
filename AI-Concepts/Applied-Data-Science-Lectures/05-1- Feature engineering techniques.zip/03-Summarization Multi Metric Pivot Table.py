# Summarization by Multi metric Pivot tables

import pandas as pd

# Sample dataset with 10 records
data = {
    'Product_Type': [
        'Electronics', 'Clothing', 'Grocery', 'Electronics', 'Clothing',
        'Grocery', 'Electronics', 'Clothing', 'Grocery', 'Electronics'
    ],
    'Store_Location': [
        'Mumbai', 'Delhi', 'Mumbai', 'Delhi', 'Mumbai',
        'Delhi', 'Mumbai', 'Delhi', 'Mumbai', 'Delhi'
    ],
    'Sales': [500, 200, 150, 300, 250, 100, 450, 180, 220, 350]
}

df = pd.DataFrame(data)

print("Original Data")
print(df)

# Multi-metric pivot table
pivot_multi = pd.pivot_table(
    df,
    values='Sales',
    index='Product_Type',
    columns='Store_Location',
    aggfunc=['sum', 'mean', 'count'],
    fill_value=0
)

print("\nMulti metric Pivot Table")
print(pivot_multi)
