# Grouping Data

import pandas as pd

# Sample dataset
data = {
    'Product_Type': [
        'Electronics', 'Clothing', 'Grocery', 'Electronics', 'Clothing',
        'Grocery', 'Electronics', 'Clothing', 'Grocery', 'Electronics'
    ],
    'Store_Location': [
        'Mumbai', 'Delhi', 'Mumbai', 'Delhi', 'Mumbai',
        'Delhi', 'Mumbai', 'Delhi', 'Mumbai', 'Delhi'
    ],
    'Sales': [500, 200, 150, 300, 250, 100, 450, 180, 220, 350]
}

df = pd.DataFrame(data)

# Print original data
print("Original Data")
print(df)

# Grouping by Product Type
group_by_product = df.groupby('Product_Type')['Sales'].sum()

# Grouping by Store Location
group_by_location = df.groupby('Store_Location')['Sales'].sum()

print("\nGrouped by Product Type:")
print(group_by_product)

print("\nGrouped by Store Location:")
print(group_by_location)

# Hierarchical grouping
# Grouping Product Type within Store Location
grouped = df.groupby(['Store_Location', 'Product_Type'])['Sales'].sum()

print("\nProduct Type grouped within Location")
print(grouped)

