# Feature Engineering techniques

'''
here is a single, comprehensive, Python program that demonstrates ALL major
feature engineering techniques we discussed.
It uses one synthetic dataset and walks through:
- Handling missing values
- Encoding categorical variables
- Scaling & normalization
- Binning
- Feature creation
- Date/time feature engineering
- Text feature engineering
- Feature selection
- Outlier handling
- Dimensionality reduction (PCA)
- Target encoding
- Group‑based aggregation features

'''
import pandas as pd
import numpy as np
from sklearn.preprocessing import (
    StandardScaler, MinMaxScaler, LabelEncoder, OneHotEncoder
)
from sklearn.impute import SimpleImputer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import PCA
from sklearn.feature_selection import VarianceThreshold
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------
# 1. CREATE SAMPLE DATASET
# ---------------------------------------------------------
df = pd.DataFrame({
    'Age': [25, 32, np.nan, 45, 28, 35, np.nan, 40],
    'Income': [50000, 60000, 55000, np.nan, 52000, 58000, 61000, 62000],
    'City': ['Mumbai', 'Delhi', 'Delhi', 'Chennai', 'Mumbai', 'Chennai', 'Delhi', 'Mumbai'],
    'Education': ['Graduate', 'Postgraduate', 'Graduate', 'PhD', 'Graduate', 'Postgraduate', 'PhD', 'Graduate'],
    'Purchase_Amount': [200, 300, 250, 400, 220, 330, 310, 390],
    'Review_Text': [
        "good product", "excellent quality", "not bad", "very poor",
        "good value", "excellent", "bad quality", "very good"
    ],
    'Date': pd.date_range(start='2024-01-01', periods=8, freq='D')
})

print("\nOriginal Data:")
print(df)

# ---------------------------------------------------------
# 2. HANDLING MISSING VALUES
# ---------------------------------------------------------
imputer_mean = SimpleImputer(strategy='mean')
df['Age'] = imputer_mean.fit_transform(df[['Age']])

imputer_median = SimpleImputer(strategy='median')
df['Income'] = imputer_median.fit_transform(df[['Income']])

print("\nAfter Handling Missing Values:")
print(df)

# ---------------------------------------------------------
# 3. ENCODING CATEGORICAL VARIABLES
# ---------------------------------------------------------
# Label Encoding (for ordinal-like)
le = LabelEncoder()
df['Education_LE'] = le.fit_transform(df['Education'])

# One-Hot Encoding (for nominal)
df = pd.get_dummies(df, columns=['City'], prefix='City')

print("\nAfter Encoding:")
print(df)

# ---------------------------------------------------------
# 4. SCALING & NORMALIZATION
# ---------------------------------------------------------
scaler = StandardScaler()
df['Age_scaled'] = scaler.fit_transform(df[['Age']])

minmax = MinMaxScaler()
df['Income_scaled'] = minmax.fit_transform(df[['Income']])

print("\nAfter Scaling:")
print(df[['Age', 'Age_scaled', 'Income', 'Income_scaled']])

# ---------------------------------------------------------
# 5. BINNING / DISCRETIZATION
# ---------------------------------------------------------
df['Age_Bin'] = pd.cut(df['Age'], bins=3, labels=['Young', 'Middle', 'Old'])

print("\nAfter Binning:")
print(df[['Age', 'Age_Bin']])

# ---------------------------------------------------------
# 6. FEATURE CREATION
# ---------------------------------------------------------
df['Income_per_Age'] = df['Income'] / df['Age']
df['Purchase_per_Age'] = df['Purchase_Amount'] / df['Age']

print("\nAfter Feature Creation:")
print(df[['Income_per_Age', 'Purchase_per_Age']])

# ---------------------------------------------------------
# 7. DATE/TIME FEATURE ENGINEERING
# ---------------------------------------------------------
df['Day'] = df['Date'].dt.day
df['Week'] = df['Date'].dt.isocalendar().week
df['Month'] = df['Date'].dt.month
df['Day_of_Week'] = df['Date'].dt.dayofweek

print("\nAfter Date/Time Feature Engineering:")
print(df[['Date', 'Day', 'Week', 'Month', 'Day_of_Week']])

# ---------------------------------------------------------
# 8. TEXT FEATURE ENGINEERING (TF-IDF)
# ---------------------------------------------------------
tfidf = TfidfVectorizer(max_features=5)
tfidf_matrix = tfidf.fit_transform(df['Review_Text']).toarray()
tfidf_df = pd.DataFrame(tfidf_matrix, columns=tfidf.get_feature_names_out())

df = pd.concat([df, tfidf_df], axis=1)

print("\nAfter Text Feature Engineering (TF-IDF):")
print(tfidf_df)

# ---------------------------------------------------------
# 9. OUTLIER HANDLING (CAPPING)
# ---------------------------------------------------------
df['Income_Capped'] = np.where(df['Income'] > df['Income'].quantile(0.95),
                               df['Income'].quantile(0.95),
                               df['Income'])

print("\nAfter Outlier Capping:")
print(df[['Income', 'Income_Capped']])

# ---------------------------------------------------------
# 10. FEATURE SELECTION (Variance Threshold)
# ---------------------------------------------------------
selector = VarianceThreshold(threshold=0.01)
selected = selector.fit_transform(df.select_dtypes(include=[np.number]))

print("\nAfter Variance Threshold Feature Selection:")
print("Selected shape:", selected.shape)

# ---------------------------------------------------------
# 11. DIMENSIONALITY REDUCTION (PCA)
# ---------------------------------------------------------
pca = PCA(n_components=2)
pca_features = pca.fit_transform(df.select_dtypes(include=[np.number]))

print("\nPCA Output (2 Components):")
print(pca_features)

# ---------------------------------------------------------
# 12. TARGET-BASED ENCODING
# ---------------------------------------------------------
df['Education_Target_Enc'] = df.groupby('Education')['Purchase_Amount'].transform('mean')

print("\nAfter Target Encoding:")
print(df[['Education', 'Education_Target_Enc']])

# ---------------------------------------------------------
# 13. GROUP-BASED AGGREGATION FEATURES
# ---------------------------------------------------------
df['Avg_Purchase_By_Education'] = df.groupby('Education')['Purchase_Amount'].transform('mean')
df['Total_Purchase_By_Week'] = df.groupby('Week')['Purchase_Amount'].transform('sum')

print("\nAfter Group-Based Aggregation Features:")
print(df[['Education', 'Avg_Purchase_By_Education', 'Week', 'Total_Purchase_By_Week']])
