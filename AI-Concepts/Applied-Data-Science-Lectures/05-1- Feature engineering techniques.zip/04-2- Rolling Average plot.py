import pandas as pd
import matplotlib.pyplot as plt

# Sample daily temperature data
data = {
    'Day': pd.date_range(start='2024-01-01', periods=15, freq='D'),
    'Temperature': [30, 32, 31, 29, 28, 28, 30, 33, 34, 32, 31, 31, 29, 28, 29]
}

df = pd.DataFrame(data)

# 3-day rolling mean (smoothened data)
df['Rolling_Mean_3'] = df['Temperature'].rolling(window=3).mean()


# 5-day rolling mean (smoothened data)
df['Rolling_Mean_5'] = df['Temperature'].rolling(window=5).mean()

# Plotting
plt.figure(figsize=(10, 5))

# Raw temperature line
plt.plot(df['Day'], df['Temperature'], marker='o', label='Raw Temperature')

# Smoothened temperature line
plt.plot(df['Day'], df['Rolling_Mean_3'], marker='o', label='3-Day Rolling Mean', linewidth=3)

# Smoothened temperature line
plt.plot(df['Day'], df['Rolling_Mean_5'], marker='o', label='5-Day Rolling Mean', linewidth=3)


# Labels and title
plt.title('Temperature Data: Raw vs Smoothened (3-Day & 5-DayRolling Mean)')
plt.xlabel('Date')
plt.ylabel('Temperature (°C)')
plt.legend()
plt.grid(True)

plt.show()
