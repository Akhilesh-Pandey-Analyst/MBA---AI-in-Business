# Grouping Data

import pandas as pd

import pandas as pd

data = {
    'Region': [
        'North', 'North', 'North', 'South', 'South', 'South',
        'East', 'East', 'East', 'West', 'West', 'West'
    ],
    'City': [
        'Delhi', 'Delhi', 'Chandigarh', 'Chennai', 'Chennai', 'Bangalore',
        'Kolkata', 'Kolkata', 'Bhubaneswar', 'Mumbai', 'Mumbai', 'Pune'
    ],
    'Product_Category': [
        'Electronics', 'Electronics', 'Clothing',
        'Clothing', 'Grocery', 'Electronics',
        'Grocery', 'Clothing', 'Electronics',
        'Electronics', 'Grocery', 'Clothing'
    ],
    'Product_Type': [
        'Mobile', 'Laptop', 'Shirts',
        'Shirts', 'Snacks', 'Laptop',
        'Snacks', 'Shirts', 'Mobile',
        'Laptop', 'Snacks', 'Shirts'
    ],
    'Sales': [500, 700, 200, 250, 150, 600, 180, 220, 550, 900, 300, 260]
}

df = pd.DataFrame(data)

print("Original Data")
print(df)

# Create hierarchial grouping
grouped_table = df.groupby(
    ['Region', 'City', 'Product_Category', 'Product_Type']
)['Sales'].sum()

print("\nGrouped table - Hierarchial")
print(grouped_table)
