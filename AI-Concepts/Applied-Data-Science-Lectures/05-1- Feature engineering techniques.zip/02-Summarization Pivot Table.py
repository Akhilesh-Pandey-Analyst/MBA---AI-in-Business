# Summarization by Pivot tables

import pandas as pd

# Sample dataset with 10 records
data = {
    'Product_Type': [
        'Electronics', 'Clothing', 'Grocery', 'Electronics', 'Clothing',
        'Grocery', 'Electronics', 'Clothing', 'Grocery', 'Electronics'
    ],
    'Store_Location': [
        'Mumbai', 'Delhi', 'Mumbai', 'Delhi', 'Mumbai',
        'Delhi', 'Mumbai', 'Delhi', 'Mumbai', 'Delhi'
    ],
    'Sales': [500, 200, 150, 300, 250, 100, 450, 180, 220, 350]
}

df = pd.DataFrame(data)

# Print data table
print("Sales Data")
print(df)

# Pivot table summarizing Sales by Product Type and Store Location
pivot_summary = pd.pivot_table(
    df,
    values='Sales',
    index='Product_Type',
    columns='Store_Location',
    aggfunc='sum',
    fill_value=0
)

print("\nPivot Table")
print(pivot_summary)
