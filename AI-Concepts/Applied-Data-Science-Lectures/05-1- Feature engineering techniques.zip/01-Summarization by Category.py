# Summarization by Category variables

import pandas as pd

# Sample dataset with 10 records
data = {
    'Product_Type': [
        'Electronics', 'Clothing', 'Grocery', 'Electronics', 'Clothing',
        'Grocery', 'Electronics', 'Clothing', 'Grocery', 'Electronics'
    ],
    'Store_Location': [
        'Mumbai', 'Delhi', 'Mumbai', 'Delhi', 'Mumbai',
        'Delhi', 'Mumbai', 'Delhi', 'Mumbai', 'Delhi'
    ],
    'Sales': [500, 200, 150, 300, 250, 100, 450, 180, 220, 350]
}

df = pd.DataFrame(data)

#0. Display data records
print("Sales Data records")
print(df)

# 1. Summarization by Product_Type
summary_by_product = df.groupby('Product_Type')['Sales'].sum().reset_index()

# 2. Summarization by Store_Location
summary_by_location = df.groupby('Store_Location')['Sales'].sum().reset_index()

# 3. Print Summarizations
print("\nSummary by Product Type:")
print(summary_by_product)

print("\nSummary by Store Location:")
print(summary_by_location)
