import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# 1. Create a sample time series
# -----------------------------
np.random.seed(42)
dates = pd.date_range(start="2024-01-01", periods=50, freq="D")
values = np.random.randint(10, 100, size=50)

df = pd.DataFrame({"Date": dates, "Value": values})
df.set_index("Date", inplace=True)

print("Original Data:")
print(df.head())

# -------------------------------------
# 2. Rolling Window: Mean, Median, Std
# -------------------------------------
print("\nRolling Window: Mean, Medin and Std")
df["Rolling_Mean_7"] = df["Value"].rolling(window=7).mean()
df["Rolling_Median_7"] = df["Value"].rolling(window=7).median()
df["Rolling_Std_7"] = df["Value"].rolling(window=7).std()
print(df.head(15))

# -------------------------------------
# 3. Rolling Min/Max
# -------------------------------------
print("\nRolling Min/Max")
df["Rolling_Min_7"] = df["Value"].rolling(window=7).min()
df["Rolling_Max_7"] = df["Value"].rolling(window=7).max()
print(df.head(15))

# -------------------------------------
# 4. Rolling Sum
# -------------------------------------
print("\nRolling Sum")
df["Rolling_Sum_7"] = df["Value"].rolling(window=7).sum()
print(df.head(15))

# -------------------------------------
# 5. Rolling Correlation & Covariance
# -------------------------------------
# Create a second synthetic series
df["Value2"] = df["Value"] * 0.5 + np.random.randint(0, 20, size=50)

print("\nRolling Correlation / Covariance")
df["Rolling_Corr_7"] = df["Value"].rolling(window=7).corr(df["Value2"])
df["Rolling_Cov_7"] = df["Value"].rolling(window=7).cov(df["Value2"])
print(df.head(15))

# -------------------------------------
# 6. Rolling Apply (Custom Function)
# -------------------------------------
# Example: Rolling range (max - min)
print("\nRolling Range")
df["Rolling_Range_7"] = df["Value"].rolling(window=7).apply(lambda x: x.max() - x.min(), raw=False)
print(df.head(15))

# --------------------------------------------
# 7. Exponentially Weighted Moving Avg
# ewma(t) = aplha * x(t) + (1-alpha)* ewma(t-1)
# ---------------------------------------------
print("\nRolling Exp Weighted Moving Average (EWMA)")
df["EWMA_0.3"] = df["Value"].ewm(alpha=0.3).mean()

print("\nRolling Statistics:")
print(df.head(15))

# -------------------------------------
# 8. Plotting (Optional)
# -------------------------------------
print("\nPlottings..")
df[["Value", "Rolling_Mean_7", "EWMA_0.3"]].plot(figsize=(12, 6), title="Rolling Mean & EWMA")
plt.show()
