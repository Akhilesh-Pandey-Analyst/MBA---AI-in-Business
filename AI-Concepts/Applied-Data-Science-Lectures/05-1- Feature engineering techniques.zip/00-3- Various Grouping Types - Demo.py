# Types of Grouping Data - Demo

import pandas as pd

# ---------------------------------------------------------
# SAMPLE DATASET
# ---------------------------------------------------------
data = {
    'Region': [
        'North', 'North', 'North', 'South', 'South', 'South',
        'East', 'East', 'East', 'West', 'West', 'West'
    ],
    'City': [
        'Delhi', 'Delhi', 'Chandigarh', 'Chennai', 'Chennai', 'Bangalore',
        'Kolkata', 'Kolkata', 'Bhubaneswar', 'Mumbai', 'Mumbai', 'Pune'
    ],
    'Product_Category': [
        'Electronics', 'Electronics', 'Clothing',
        'Clothing', 'Grocery', 'Electronics',
        'Grocery', 'Clothing', 'Electronics',
        'Electronics', 'Grocery', 'Clothing'
    ],
    'Product_Type': [
        'Mobile', 'Laptop', 'Shirts',
        'Shirts', 'Snacks', 'Laptop',
        'Snacks', 'Shirts', 'Mobile',
        'Laptop', 'Snacks', 'Shirts'
    ],
    'Sales': [500, 700, 200, 250, 150, 600, 180, 220, 550, 900, 300, 260]
}

df = pd.DataFrame(data)

# ---------------------------------------------------------
# ADD SYNTHETIC DATE COLUMN
# ---------------------------------------------------------
df['Date'] = pd.date_range(start='2024-01-01', periods=len(df), freq='D')

# 0. Print Original Data
print("Original Data")
print(df)

# ---------------------------------------------------------
# 1. SINGLE-LEVEL GROUPING
# ---------------------------------------------------------
print("\n1. Grouping by Product Category (Single-Level):")
print(df.groupby('Product_Category')['Sales'].sum())

# ---------------------------------------------------------
# 2. MULTI-LEVEL GROUPING
# ---------------------------------------------------------
print("\n2. Grouping by Region and City (Multi-Level):")
print(df.groupby(['Region', 'City'])['Sales'].sum())

# ---------------------------------------------------------
# 3. NESTED GROUPING (Sub-groups within groups)
# ---------------------------------------------------------
print("\n3. Nested Grouping: Region → City → Category → Type:")
print(df.groupby(['Region', 'City', 'Product_Category', 'Product_Type'])['Sales'].sum())

# ---------------------------------------------------------
# 4. PIVOT-STYLE GROUPING (Matrix)
# ---------------------------------------------------------
print("\n4. Pivot Table: Product Category × Region:")
pivot_table = pd.pivot_table(
    df,
    values='Sales',
    index='Product_Category',
    columns='Region',
    aggfunc='sum',
    fill_value=0
)
print(pivot_table)

# ---------------------------------------------------------
# 5. MULTI-METRIC GROUPING
# ---------------------------------------------------------
print("\n5. Multi-Metric Grouping on Product Category:")
print(df.groupby('Product_Category')['Sales'].agg(['sum', 'mean', 'count']))

# ---------------------------------------------------------
# 6. GROUPING WITH FILTERING
# ---------------------------------------------------------
print("\n6. Grouping after Filtering (Only Mumbai):")
print(df[df['City'] == 'Mumbai'].groupby('Product_Category')['Sales'].sum())

# ---------------------------------------------------------
# 7. GROUPING WITH CUSTOM FUNCTION
# ---------------------------------------------------------
print("\n7. Custom Function: Range of Sales within each Region:")
print(df.groupby('Region')['Sales'].apply(lambda x: x.max() - x.min()))

# ---------------------------------------------------------
# 8. TIME-BASED GROUPING (Using Synthetic Date Column, group by ISO week number)
# ---------------------------------------------------------
print("\n8. Time-Based Grouping (Weekly Sales using synthetic dates):")
weekly_sales = df.groupby(df['Date'].dt.isocalendar().week)['Sales'].sum()
print(weekly_sales)
