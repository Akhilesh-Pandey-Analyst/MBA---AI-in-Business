# Matplotlib trial program

import matplotlib.pyplot as plt

# Data
x = [1, 2, 3, 4, 5]
y = [2, 4, 1, 6, 3]

# Create the plot
plt.plot(x, y, marker='o', linestyle='-', color='blue')

# Add labels and title
plt.title("Sample Line Plot")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")

# Display the plot
plt.show()

# Scatter plot

x = [5, 7, 8, 7, 2, 17, 2, 9, 4, 11]
y = [99, 86, 87, 88, 100, 86, 103, 87, 94, 78]

# Create scatter plot
plt.scatter(x, y, color='purple', marker='o')

# Add labels and title
plt.title("Sample Scatter Plot")
plt.xlabel("X Values")
plt.ylabel("Y Values")

# Display the plot
plt.show()


