# basic bar chart

from matplotlib import pyplot as plt

# Data tree heights and their counts
tree_ht = [5,12,10,6,7,9,11,8,16] 
counts = [12,16,6,16,9,15,7,11,2]  

# plot bar
plt.bar(tree_ht, counts, align = 'center', color='r' , edgecolor='b') 

plt.title('Bar Graph') 
plt.ylabel('Count values') 
plt.xlabel('Tree height')  

# show graph
plt.show()

