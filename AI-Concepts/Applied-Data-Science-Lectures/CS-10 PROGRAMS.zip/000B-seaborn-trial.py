# Seaborn trial program

import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme()
tips = sns.load_dataset("tips")

# Display data
print("Data set")
print(tips.head())
print()

sns.relplot(
    data=tips,
    x="total_bill",
    y="tip",
    hue="smoker",
    col="time",
    kind="scatter"
)

plt.show()
