# Basic EDA on titanic.csv

import warnings
warnings.filterwarnings("ignore")

#Load the required libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt


#Load the data
df = pd.read_csv('titanic.csv')

 
#View the data
print(df.head())
print("Shape of the input data is : ", df.shape)
print()

# display basic information about the data
print("Displaying information about the data : ")
print("Also displays the number of non null values in each column ")
print(df.info())
print()

# display the statistical info of the data
print("Displaying basic statistics of the data : ")
print(df.describe())
print()

# find the duplicates in the data
print("Number of duplicate records = : ", df.duplicated().sum())

# find the number of unique columns in the data
#unique values
print("Print unique Values for the columns") 
print("unique values of Pclass ", df['Pclass'].unique())
print("unique values of Survided ", df['Survived'].unique()) 
print("Unique values of Sex " , df['Sex'].unique())
print()

# plot counts on categorical data

print("Generate a plot of Pclass values") 
sns.countplot(x='Pclass', data=df)
plt.show()
print()
print("Pclass split by gender")
sns.countplot(x='Sex', hue='Pclass', data=df)
plt.show()
print()
input("Press key to continue")

# find null values in the data

print("Null values in the data is :")
print(df.isnull().sum())
print()


# replace null values with 0
#df.replace(np.nan,'0',inplace = True)
# replace null values with mean
df.fillna(df.select_dtypes(include='number').mean(), inplace=True)
#df.replace(np.nan, df.mean(), inplace = True)

print("after replacing :") 
#Check the changes now
print(df.isnull().sum())
print()

#drop a few features in columns
print("Dropping a few columns")
notneeded = ['PassengerId', 'Name','Ticket']
cleaned = df.drop(columns=notneeded)   # drop columns in notneeded list
print(cleaned.head())
print()


# count infants and children
# 
infants = len(cleaned[(cleaned.Age < 3)]) 
children = len(cleaned[(cleaned.Age >= 3) & (cleaned.Age < 10)]) 
print(f'There were {infants} infants and {children} children on board the Titanic')
print()

##################################################################################
# Generate few plots

input("Press key to continue")

# plot histogram on the Age feature
# kde is kernel density estimator which smoothens values, if set True
sns.histplot(cleaned.Age, kde=True, bins=20)
plt.xlabel("Age")
plt.ylabel("Counts")
plt.grid(True)
plt.show()

input("Press key to continue")
input("WAIT")

# colours on Age
# set the colors 
cmap = plt.get_cmap('Pastel1')
young = cmap(0.5)
middle = cmap(0.2)
older = cmap(0.8)

# create histogram for 10 bins
# get the object we will change - bars is an array with len: num of bins
y_values, bins, bars = plt.hist(cleaned.Age, bins=10)

# assign colours to bars
[bars[i].set_facecolor(young) for i in range(0,1)] # bin 0
[bars[i].set_facecolor(middle) for i in range(1,3)] # bins 1 and 2
[bars[i].set_facecolor(older) for i in range(3,10)] # 7 remaining bins

plt.title("Age histogram")
plt.xlabel("Age")
plt.ylabel("Counts")
plt.grid(True)
plt.show()

input("Press key to continue")

#Kernel Density Estimation
#The kernel density estimate is used for plotting the shape of a distribution.
#The bandwidth (bw_adjust) parameter of the KDE controls how tightly the estimation is
#fit to the data.


# data x and y axis for seaborn
x= np.random.randn(200)
y = np.random.randn(200)
  
# Kde for x values. 
sns.kdeplot(x)
plt.show()

'''
sns.kdeplot(x,y,shade=True)
plt.show()
'''
#sns.histplot(cleaned.Age, kde=True, bins=20)   # histogram with the kde plot
sns.kdeplot(cleaned.Age, label="bw: Default", shade=True, color="b") # same as bw = 1.0
#sns.kdeplot(cleaned.Age, bw_adjust=0.2, label="bw: 0.2", shade=True, color="r")
#sns.kdeplot(cleaned.Age, bw_adjust=0.6, label="bw: 0.6", shade=True, color="g")
#sns.kdeplot(cleaned.Age, bw_adjust=2.0, label="bw: 2.0", shade=True, color='c')

plt.grid(True)
plt.legend(loc="upper right")
plt.xlabel('Age')
plt.title("Histogram with kde")
plt.show()


input("Press key to continue")

#######################################################################
# Boxplot for Distribution
# seaborn boxplot for Age attribute
sns.boxplot(x='Age', data=cleaned)

#ax = sns.boxplot(x=cleaned['Age']) # another way to write the same
plt.ylabel(None)
plt.xlabel('Age', fontsize=12)
plt.title('Distribution of age in the Data', fontsize=12)
plt.show()

#multiple Boxplots
sns.boxplot(x='Pclass', y='Age', data=cleaned)
plt.ylabel("Age")
plt.xlabel('Pclass', fontsize=12)
plt.title('Distribution of age by Pclass in the Data', fontsize=12)
plt.show()

#using pandas directly
cleaned.boxplot('Age', by='Pclass')
plt.title("Pandas generated boxplot")
plt.show()


print("Done")
