import matplotlib.pyplot as plt

# Sample data
x = [5, 7, 8, 7, 2, 17, 2, 9, 4, 11]
y = [99, 86, 87, 88, 100, 86, 103, 87, 94, 78]

# Color values (mapped to a colormap)
colors = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

# Size values (each point gets a different size)
data_val = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500]

# Create scatter plot
plt.scatter(x, y, c=colors, s=data_val, cmap='viridis', alpha=0.7)

#plt.scatter(x, y, c=y, s=sizes, cmap='viridis', alpha=0.7)


# Add colorbar to show color meaning
plt.colorbar(label="Color Scale")

# Labels and title
plt.title("Scatter Plot with Color and Size Variations")
plt.xlabel("X Values")
plt.ylabel("Y Values")

# Display the plot
plt.show()
