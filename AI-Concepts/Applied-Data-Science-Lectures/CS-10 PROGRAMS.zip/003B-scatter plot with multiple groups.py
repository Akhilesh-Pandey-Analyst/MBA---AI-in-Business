# scatter plot with multiple groups

import matplotlib.pyplot as plt

# Sample data for three groups
group1_x = [1, 2, 3, 4]
group1_y = [2, 3, 2, 5]

group2_x = [2, 3, 4, 5]
group2_y = [5, 6, 5, 7]

group3_x = [3, 4, 5, 6]
group3_y = [1, 2, 1, 3]

# Plot each group separately
plt.scatter(group1_x, group1_y, color='red', marker='o', label='Group A')
plt.scatter(group2_x, group2_y, color='blue', marker='s', label='Group B')
plt.scatter(group3_x, group3_y, color='green', marker='^', label='Group C')

# Labels and title
plt.title("Scatter Plot with Multiple Groups")
plt.xlabel("X Values")
plt.ylabel("Y Values")

# Show legend
plt.legend()

# Display the plot
plt.show()
