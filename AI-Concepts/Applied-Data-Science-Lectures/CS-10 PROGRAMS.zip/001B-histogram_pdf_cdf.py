# histogram plot and bell curve

# defining required libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# No of Data points
N = 500

# initializing random values
data = np.random.randn(N)
#data = np.random.randint(1,20,N)
#data = np.random.normal(0.5, 1, N) # mu = 0.5, sigma = 1 Gaussian Distribution
print(data)
print()

# get mean value
mean_val= data.mean()
print("mean value is : " , mean_val)
print()

# getting data as a the histogram
count, bin_edges = np.histogram(data, bins=15)

print("Bin Edges are : ")
print(bin_edges)
print()
print("Bin Counts are : ")
print(count)
print()

# finding the PDF of the histogram using count values
pdf = count / sum(count)

# using numpy np.cumsum to calculate the CDF
# We can also find using the PDF values by looping and adding
cdf = np.cumsum(pdf)

# plotting PDF and CDF
plt.plot(data)
plt.title("Original Data")
plt.show()

plt.bar(bin_edges[1:], count, color='khaki')
#plt.hist(data , cumulative =False)
plt.plot(bin_edges[1:], count, color ="red", label="counts")  # line graph
plt.plot([mean_val, mean_val] , [0,100], linestyle="dotted")  # line at mean
plt.title("Histogram")
plt.show()


# plot PDF and CDF
plt.plot([mean_val, mean_val] , [0,1], linestyle="dotted")  # line at mean
plt.plot(bin_edges[1:], pdf, color="red", label="PDF")
plt.plot(bin_edges[1:], cdf, color ="green", label="CDF")
plt.legend()
plt.title("PDF & CDF Plot")
plt.show()

print("Done")
