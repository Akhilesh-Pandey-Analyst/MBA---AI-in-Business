import matplotlib.pyplot as plt
import random

# list of values are interpreted as a sequence of y values for x=0 onwards
plt.plot([2,5,4,1,3,6,3,7])
plt.xlabel('sample no')
plt.ylabel('values')


plt.show()

input("Press Enter")
###########################################
# create a list of random values
lst=[]
for i in range (20):
    lst.append(random.randint(0,9)) # append random values betw 0-9
    
print ('values are: ',lst)
plt.plot(lst , 'r')   # line color is red
plt.plot(lst , '^b')  # blue triangle markers
plt.xlabel('sample no')
plt.ylabel('some values')
plt.show()

