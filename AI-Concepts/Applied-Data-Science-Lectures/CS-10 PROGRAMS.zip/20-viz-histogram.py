#histogram of rainfall
# assume rainfall data for 30 days
# min rainfall = 0, maximum is 100 mm
# plot histogram in 10 uniform ranges
rain=[]
numdays=30

# get input 
for i in range(numdays):
   v=int(input("Enter rainfall for " + str(i+1)+": "))
   rain.append(v)

# calculate the frequency counts
counts=[0,0,0,0,0,0,0,0,0,0]
for i in range(numdays):
   counts[rain[i]//10] +=1

# generate plot25

bins=[1,2,3,4,5,6,7,8,9,10]    # x axis

import matplotlib.pyplot as plt
plt.bar(bins,counts)   # bar plot of counts
plt.show()    # show the graph
