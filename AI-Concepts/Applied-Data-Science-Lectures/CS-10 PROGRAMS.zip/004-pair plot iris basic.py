# Basic pair plot trial program
# for iris data 

import seaborn as sns
import matplotlib.pyplot as plt

# Load the iris dataset
iris = sns.load_dataset("iris")

# display a few records
print("Sample data")
print(iris.head())
print()

# Create the pair plot
sns.pairplot(iris, hue="species")

# Show the plot
plt.show()
